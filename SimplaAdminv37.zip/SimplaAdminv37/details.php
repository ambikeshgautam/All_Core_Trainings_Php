<?php include('header.php'); ?>
<?php include('PageHead.php'); ?>
<?php include('action.php'); ?>


<div class="container">
  <h2>About the Category <?php echo $vname ; ?> </h2>
  <div class="panel panel-default">
    <div class="panel-heading"><?php echo $vdetail; ?> </div>
  </div>
</div>

<?php include('footer.php');?>